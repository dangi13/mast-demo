package mast.api.test.mast;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import mast.api.listeners.ExtentReporter;
import mast.api.service.mast.AuthService;
import mast.api.service.mast.model.AccessToken;
import mast.api.utils.http.IRestResponse;

public class MastTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(MastTest.class);

	@BeforeClass
	public void setup() {
		LOGGER.info("Setting up Mast tests");
	}

	@Test(testName = "MAST_02", description = "Validate auth")
	public void testE2eFlow() {
		// arrange
		ExtentReporter.info("Get Auth token");
		
		IRestResponse<AccessToken> token = AuthService.getBearerToken();
		ExtentReporter.info(token.getResponse().prettyPrint());
		String accessToken = token.getBody().getAccessToken();
		
		// assert
		Assert.assertFalse(accessToken.isEmpty(), "Token is empty");
	}

}
