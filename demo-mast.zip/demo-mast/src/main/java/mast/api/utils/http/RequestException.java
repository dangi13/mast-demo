package mast.api.utils.http;
public class RequestException extends Exception {

    private static final long serialVersionUID = 1L;

	public RequestException(String message) {
        super(message);
    }

    public RequestException(Exception ex) {
        super(ex);
    }

}