package mast.api.utils.http;
import static io.restassured.RestAssured.given;

import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.config.EncoderConfig;
import io.restassured.filter.Filter;
import io.restassured.http.ContentType;
import io.restassured.http.Cookies;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import mast.api.utils.http.constants.HttpStatus;

public class RestClient {

    private RequestSpecBuilder requestSpecBuilder;
    private RequestSpecification requestSpecification;

    private HttpStatus expectedStatusCode = HttpStatus.OK;
    private String expectedResponseContentType;
    private Response apiResponse;

    /**
     * Returns a new object of RestUtil class
     *
     * @return this
     * @throws RequestException
     */
    public static RestClient init(){
        return new RestClient();
    }

    /**
     * RestUtil Default Constructor
     *
     * @throws RequestException
     */
    public RestClient() {
        initializeRequestSpec();
    }


    private void initializeRequestSpec() {

        EncoderConfig encoderconfig = new EncoderConfig();
        requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setBaseUri(mast.api.utils.common.Config.getProperty("BASE_URL"));
        requestSpecBuilder.setConfig(RestAssured.config().encoderConfig(encoderconfig.appendDefaultContentCharsetToContentTypeIfUndefined(false)));
    }

    /**
     * Defines API Endpoint Path to Request Specification
     *
     * @param path
     * @return this
     */
    public RestClient path(String path) {
        requestSpecBuilder.setBasePath(path);
        return this;
    }
    
    public RestClient formParams(Map<String, ?> formParams) {
        requestSpecBuilder.addFormParams(formParams);
        return this;
    }

    /**
     * Defines Path Parameters to Request Specification
     *
     * @param key
     * @param value
     * @return this
     */
    public RestClient pathParam(String key, String value) {
        requestSpecBuilder.addPathParam(key, value);
        return this;
    }

    /**
     * Defines Query Parameters to Request Specification
     *
     * @param key
     * @param value
     * @return this
     */
    public RestClient queryParam(String key, String value) {
        requestSpecBuilder.addQueryParam(key, value);
        return this;
    }

    /**
     * Defines Content Type Header to Request Specification
     *
     * @param contentType
     * @return this
     */
    public RestClient contentType(ContentType contentType) {
        requestSpecBuilder.setContentType(contentType);
        return this;
    }
    
    public RestClient contentType(String contentType) {
        requestSpecBuilder.setContentType(contentType);
        return this;
    }


    /**
     * Defines Headers to Request Specification
     *
     * @param headers
     * @return this
     */
    public RestClient headers(Map<String, String> headers) {
        requestSpecBuilder.addHeaders(headers);
        return this;
    }

    /**
     * Defines Cookies to Request Specification
     *
     * @param cookies
     * @return this
     */
    public RestClient cookies(Map<String, String> cookies) {
        requestSpecBuilder.addCookies(cookies);
        return this;
    }

    /**
     * Defines Cookies to Request Specification
     *
     * @param cookies
     * @return this
     */
    public RestClient cookies(Cookies cookies) {
        requestSpecBuilder.addCookies(cookies);
        return this;
    }

    /**
     * Defines Cookie to Request Specification
     *
     * @param cookie
     * @return this
     */
    public RestClient filter(Filter filter) {
        requestSpecBuilder.addFilter(filter);
        return this;
    }

    /**
     * Defines the Expected Status Code following successful api execution for validation
     *
     * @param expectedStatusCode
     * @return this
     */
    public RestClient expectedStatusCode(HttpStatus expectedStatusCode) {
        this.expectedStatusCode = expectedStatusCode;
        return this;
    }

    /**
     * Defines the Expected Response Content Type following successful api execution for validation
     *
     * @param contentType
     * @return this
     */
    public RestClient expectedResponseContentType(ContentType contentType) {
        this.expectedResponseContentType = contentType.toString();
        return this;
    }

    /**
     * Defines the Expected Response Content Type following successful api execution for validation
     *
     * @param contentType
     * @return this
     */
    public RestClient expectedResponseContentType(String contentType) {
        this.expectedResponseContentType = contentType;
        return this;
    }

    /**
     * Hits the Pre-Defined Request Specification as PUT Request
     * <p>
     * On successful response, method validates:
     * -   Status Code against the Status Code provided in Request Specification
     * -   Content Type against the Content Type provided in Request Specification
     *
     * @return this
     */
    public Response put() {
        requestSpecification = requestSpecBuilder.build();
        Response apiResponse = given().log().all()
                        .spec(requestSpecification)
                        .when()
                        .put()
                        .then()
                        .assertThat()
                        .statusCode(expectedStatusCode.getCode())
                        .and()
                        .extract()
                        .response();

        return apiResponse;
    }

    /**
     * Hits the Pre-Defined Request Specification as DELETE Request
     * <p>
     * On successful response, method validates:
     * -   Status Code against the Status Code provided in Request Specification
     * -   Content Type against the Content Type provided in Request Specification
     *
     * @return this
     */
    public Response delete() {
        requestSpecification = requestSpecBuilder.build();
        Response apiResponse = given().log().all()
                        .spec(requestSpecification)
                        .when()
                        .delete()
                        .then()
                        .assertThat()
                        .statusCode(expectedStatusCode.getCode())
                        .and()
                        .extract()
                        .response();

        return apiResponse;
    }

    /**
     * Hits the Pre-Defined Request Specification as POST Request
     * <p>
     * On successful response, method validates:
     * -   Status Code against the Status Code provided in Request Specification
     * -   Content Type against the Content Type provided in Request Specification
     *
     * @return this
     */
    public Response post() {
        requestSpecification = requestSpecBuilder.build();
        Response apiResponse = given().log().all()
                        .spec(requestSpecification)
                        .when()
                        .post()
                        .then()
                        .assertThat()
                        .statusCode(expectedStatusCode.getCode())
                        .and()
                        .extract()
                        .response();

        return apiResponse;
    }

    /**
     * Hits the Pre-Defined Request Specification as GET Request
     * <p>
     * On successful response, method validates:
     * -   Status Code against the Status Code provided in Request Specification
     * -   Content Type against the Content Type provided in Request Specification
     *
     * @return this
     */
    public Response get() {
        requestSpecification = requestSpecBuilder.build();
        Response apiResponse = given().log().all()
                        .spec(requestSpecification)
                        .when()
                        .get()
                        .then()
                        .assertThat()
                        .statusCode(expectedStatusCode.getCode())
                        .and()
                        .extract()
                        .response();

        return apiResponse;
    }

}