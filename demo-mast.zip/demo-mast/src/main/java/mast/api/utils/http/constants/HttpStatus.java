package mast.api.utils.http.constants;

public enum HttpStatus {

	OK(200, "OK"),
    CREATED(201, "Created"),
    ACCEPTED(202, "Accepted");
	
	
	private int code;
    private String desc;
    private String text;

    HttpStatus(int code, String desc) {
        this.code = code;
        this.desc = desc;
        this.text = Integer.toString(code);
    }


    public int getCode() {
        return code;
    }

    public String asText() {
        return text;
    }

    
    public String getDesc() {
        return desc;
    }
}

