package mast.api.utils.http.constants;

public class Header {
	
	public static final String X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded; charset=utf-8";

}
