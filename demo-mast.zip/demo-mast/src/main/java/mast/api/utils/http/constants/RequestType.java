package mast.api.utils.http.constants;

public enum RequestType {
	POST, PUT, GET, PATCH, DELETE
}
