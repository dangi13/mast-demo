package mast.api.service.mast;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.restassured.response.Response;
import mast.api.listeners.ExtentReporter;
import mast.api.model.Endpoint;
import mast.api.service.mast.model.RCBTeam;
import mast.api.utils.common.Config;
import mast.api.utils.http.IRestResponse;
import mast.api.utils.http.RequestException;
import mast.api.utils.http.RestClient;
import mast.api.utils.http.RestResponse;
import mast.api.utils.http.constants.RequestType;
import mast.api.utils.http.filters.OverrideContentTypeFilter;

/** This service will is responsible for all data operations for the RCB team.
 *
 * @author jaikant
 *
 */
public class RCBService {
	private static final Logger LOGGER = LoggerFactory.getLogger(RCBService.class);
	private static final Map<String, Endpoint> OPERATIONS = new HashMap<String, Endpoint>() {
		private static final long serialVersionUID = 1L;
		{
			put("RCB_PLAYER_LIST", new Endpoint(RequestType.GET, Config.getProperty("RCB_PLAYER_LIST")));
          // we can put here all the end points that are present in RCB service
		}
	};

	/**
	 *  It will retrieve data for RCB players.
	 * @return RCBTeam object
	 * @throws RequestException 
	 */
	public static IRestResponse<RCBTeam> getRCBPlayerList() {
		ExtentReporter.info("Getting RCB player list");
		Endpoint endpointDetails = OPERATIONS.get("RCB_PLAYER_LIST");
		Response response = RestClient.init().filter(new OverrideContentTypeFilter()).path(endpointDetails.getPath()).get();
		
		return new RestResponse<>(RCBTeam.class, response);
	}
	
}
