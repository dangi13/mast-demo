package mast.api.service.mast;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.restassured.response.Response;
import mast.api.listeners.ExtentReporter;
import mast.api.model.Endpoint;
import mast.api.service.mast.model.AccessToken;
import mast.api.utils.common.Config;
import mast.api.utils.http.IRestResponse;
import mast.api.utils.http.RequestException;
import mast.api.utils.http.RestClient;
import mast.api.utils.http.RestResponse;
import mast.api.utils.http.constants.Header;
import mast.api.utils.http.constants.RequestType;

public class AuthService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthService.class);
	private static final Map<String, Endpoint> OPERATIONS = new HashMap<String, Endpoint>() {
		private static final long serialVersionUID = 1L;
		{
			put("AUTH_API", new Endpoint(RequestType.POST, Config.getProperty("AUTH_API")));
		}
	};

	/**
	 *  It will retrieve data for RCB players.
	 * @return RCBTeam object
	 * @throws RequestException 
	 */
	public static IRestResponse<AccessToken> getBearerToken() {
		ExtentReporter.info("Getting bearer token");
		Endpoint endpointDetails = OPERATIONS.get("AUTH_API");
		
		Map<String, String> authParams = Map.of("grant_type", Config.getProperty("GRANT_TYPE"), 
				"audience", Config.getProperty("AUDIENCE"), 
                "clientSecret", Config.getProperty("CLIENT_SECRET"),
                "client_id", Config.getProperty("CLIENT_ID")); 
		
		Response response = RestClient.init()
				.contentType(Header.X_WWW_FORM_URLENCODED)
				.path(endpointDetails.getPath())
				.formParams(authParams).post();
		
		return new RestResponse<>(AccessToken.class, response);
	}

}
