package mast.api.model;

import mast.api.utils.http.constants.RequestType;

public class Endpoint {

	private String path;
	private RequestType requestType;

	public Endpoint(RequestType requestType, String path) {
		super();
		this.requestType = requestType;
		this.path = path;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String route) {
		this.path = route;
	}

	public RequestType getRequestType() {
		return requestType;
	}

	public void setRequestType(RequestType requestType) {
		this.requestType = requestType;
	}

}
